# -hamgman-the-psychic-winner
This game is in Python
